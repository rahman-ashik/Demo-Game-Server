Group Members
- Ashikur Rahman #23815068
- James Park #23110225
- Asif Talukder #23520477

To run :  
	compile frist from the terminal : 
		javac Connect4.java
		javac GameServer.java
		javac PlayerClient.java
		javac StateManager.java
	then run the program :
		java GameServer
		java PlayerClient


